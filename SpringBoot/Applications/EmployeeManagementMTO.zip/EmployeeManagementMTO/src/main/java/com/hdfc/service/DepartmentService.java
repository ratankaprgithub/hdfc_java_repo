package com.hdfc.service;

import java.util.List;

import com.hdfc.dto.DeptRequestDTO;
import com.hdfc.dto.DeptResponseDTO;

public interface DepartmentService {


	public DeptResponseDTO addNewDepartment(DeptRequestDTO dto);
	
	public List<DeptResponseDTO> getAllDepartment();
	
	
	
	
}
