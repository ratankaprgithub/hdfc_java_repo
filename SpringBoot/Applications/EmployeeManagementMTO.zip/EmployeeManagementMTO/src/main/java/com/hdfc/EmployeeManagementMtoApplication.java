package com.hdfc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementMtoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementMtoApplication.class, args);
	}

}
