package com.hdfc.dto;

import lombok.Data;

@Data
public class DeptRequestDTO {

	private String deptName;
	
	private String location;
	
}
