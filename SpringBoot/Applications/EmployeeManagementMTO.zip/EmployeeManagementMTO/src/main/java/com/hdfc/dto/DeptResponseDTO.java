package com.hdfc.dto;

import lombok.Data;

@Data
public class DeptResponseDTO {

	private Integer deptId;
	
	private String deptName;
	
	private String location;
	
}
