package com.hdfc.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.hdfc.dto.DeptRequestDTO;
import com.hdfc.dto.DeptResponseDTO;
import com.hdfc.entity.Department;
import com.hdfc.repository.DepartmentRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DepartmentServiceImpl implements DepartmentService{

	private final DepartmentRepository deptRepo;
	
	
	@Override
	public DeptResponseDTO addNewDepartment(DeptRequestDTO dto) {
		
		
		Department dept = new Department();
		dept.setDeptName(dto.getDeptName());
		dept.setLocation(dto.getLocation());
		
		
		Department savedDept=  deptRepo.save(dept);
		
		DeptResponseDTO responseDto= new DeptResponseDTO();
		responseDto.setDeptId(savedDept.getDeptId());
		responseDto.setDeptName(savedDept.getDeptName());
		responseDto.setLocation(savedDept.getLocation());
		
		return responseDto;
		
	}


	@Override
	public List<DeptResponseDTO> getAllDepartment() {
		
		return deptRepo.findAll().stream().map(dept -> {
			
			DeptResponseDTO responseDto = new DeptResponseDTO();
			responseDto.setDeptId(dept.getDeptId());
			responseDto.setDeptName(dept.getDeptName());
			responseDto.setLocation(dept.getLocation());
			
			
			return responseDto;
			
		}).collect(Collectors.toList());
	}
	
	
	

}
