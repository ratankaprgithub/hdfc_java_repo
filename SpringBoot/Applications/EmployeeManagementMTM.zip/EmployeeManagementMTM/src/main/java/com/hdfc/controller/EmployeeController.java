package com.hdfc.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hdfc.dto.EmployeeRequestDTO;
import com.hdfc.dto.EmployeeResponseDTO;
import com.hdfc.service.EmployeeService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/employees")
@RequiredArgsConstructor
public class EmployeeController {

	private final EmployeeService service;

	@PostMapping
	public ResponseEntity<EmployeeResponseDTO> saveEmployee(@RequestBody EmployeeRequestDTO dto) {

		EmployeeResponseDTO responseDTO = service.saveEmployee(dto);

		return ResponseEntity.status(HttpStatus.CREATED).body(responseDTO);

	}

	@GetMapping
	public List<EmployeeResponseDTO> getAllEmployees() {

		return service.getAllEmployees();
	}

	@GetMapping("/{id}")
	public EmployeeResponseDTO getEmployeeById(@PathVariable Integer id) {

		return service.getEmployeeById(id);
	}

	@PutMapping("/{id}")
	public EmployeeResponseDTO updateEmployee(@PathVariable Integer id, @RequestBody EmployeeRequestDTO dto) {

		return service.updateEmployee(id, dto);
	}

	@DeleteMapping("/{id}")
	public EmployeeResponseDTO deleteEmployee(@PathVariable Integer id) {

		return service.deleteEmployee(id);

	}
}