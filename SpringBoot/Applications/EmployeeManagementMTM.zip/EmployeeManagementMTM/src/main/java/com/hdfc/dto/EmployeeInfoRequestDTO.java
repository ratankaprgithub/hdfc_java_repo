package com.hdfc.dto;

import lombok.Data;

@Data
public class EmployeeInfoRequestDTO {

    private String empName;

    private String email;

    private Double salary;

}