package com.hdfc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementMtmApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementMtmApplication.class, args);
	}

}
