package com.hdfc.service;

import java.util.List;

import com.hdfc.dto.DeptRequestDTO;
import com.hdfc.dto.DeptResponseDTO;
import com.hdfc.dto.EmployeeInfoRequestDTO;
import com.hdfc.dto.EmployeeInfoResponseDTO;

public interface DepartmentService {


	public DeptResponseDTO addNewDepartment(DeptRequestDTO dto);
	
	public List<DeptResponseDTO> getAllDepartment();
	
	public List<EmployeeInfoResponseDTO> getEmployeesByDepartmentId(Integer deptId);
	
	
}
