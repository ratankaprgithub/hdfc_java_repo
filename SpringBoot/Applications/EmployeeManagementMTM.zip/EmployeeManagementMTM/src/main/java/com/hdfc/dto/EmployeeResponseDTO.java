package com.hdfc.dto;

import lombok.Data;

@Data
public class EmployeeResponseDTO {

    private Integer empId;

    private String empName;

    private String email;

    private Double salary;

    private String departmentName;

    private String location;
}