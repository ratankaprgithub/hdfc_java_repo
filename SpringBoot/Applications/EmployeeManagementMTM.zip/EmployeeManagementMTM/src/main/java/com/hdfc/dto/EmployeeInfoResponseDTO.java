package com.hdfc.dto;

import lombok.Data;

@Data
public class EmployeeInfoResponseDTO {
	 
	private Integer empId;

	    private String empName;

	    private String email;

	    private Double salary;
}
