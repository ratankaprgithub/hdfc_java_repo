package com.hdfc.dto;

import lombok.Data;

@Data
public class EmployeeRequestDTO {

	private String empName;

	private String email;

	private Double salary;

	private String deptName;


}
