package com.hdfc.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class DeptResponseDTO {

	private Integer deptId;

	private String deptName;

	private String location;

	private List<EmployeeInfoResponseDTO> employees = new ArrayList<>();

}
