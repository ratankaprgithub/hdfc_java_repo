package com.hdfc.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class DeptRequestDTO {

	private String deptName;

	private String location;
	
	private List<EmployeeInfoRequestDTO> employees = new ArrayList<>();
}
