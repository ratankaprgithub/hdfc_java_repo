package com.hdfc.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.hdfc.dto.EmployeeRequestDTO;
import com.hdfc.dto.EmployeeResponseDTO;
import com.hdfc.entity.Department;
import com.hdfc.entity.Employee;
import com.hdfc.repository.DepartmentRepository;
import com.hdfc.repository.EmployeeRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

	private final EmployeeRepository employeeRepo;
	private final DepartmentRepository deptRepo;

	
	
	
	@Override
	public EmployeeResponseDTO saveEmployee(EmployeeRequestDTO dto) {

		
		Department dept= deptRepo
								.findByDeptName(dto.getDeptName())
								.orElseThrow(() -> new RuntimeException("Department Does not exist "+dto.getDeptName()));

		Employee employee = new Employee();

		employee.setEmpName(dto.getEmpName());
		employee.setEmail(dto.getEmail());
		employee.setSalary(dto.getSalary());
		
		employee.setDepartment(dept);
		
		dept.getEmployees().add(employee);

		Employee savedEmployee = employeeRepo.save(employee);

		return mapToResponseDTO(savedEmployee);
	}

	@Override
	public List<EmployeeResponseDTO> getAllEmployees() {

		return employeeRepo
				.findAll()
				.stream()
				.map(this::mapToResponseDTO)
				.collect(Collectors.toList());
	}

	@Override
	public EmployeeResponseDTO getEmployeeById(Integer empId) {

		Employee employee = employeeRepo.findById(empId)
										.orElseThrow(() -> new RuntimeException("Employee Not Found"));

		return mapToResponseDTO(employee);
	}

	@Override
	public EmployeeResponseDTO updateEmployee(Integer empId, EmployeeRequestDTO dto) {

		Employee employee = employeeRepo.findById(empId)
				.orElseThrow(() -> new RuntimeException("Employee Not Found"));
		
		Department dept= deptRepo.findByDeptName(dto.getDeptName()).orElseThrow(() -> new RuntimeException("Department Name does not exist.."));
		

		employee.setEmpName(dto.getEmpName());
		employee.setEmail(dto.getEmail());
		employee.setSalary(dto.getSalary());
		employee.setDepartment(dept);

		Employee updatedEmployee = employeeRepo.save(employee);

		return mapToResponseDTO(updatedEmployee);
	}

	@Override
	public EmployeeResponseDTO deleteEmployee(Integer empId) {

		Employee existingEmployee= employeeRepo.findById(empId).orElseThrow(() -> new RuntimeException("Employee Does not exist with id: "+empId));
		
		employeeRepo.delete(existingEmployee);
		
		return mapToResponseDTO(existingEmployee);
		
		
	}

	private EmployeeResponseDTO mapToResponseDTO(Employee employee) {

		EmployeeResponseDTO dto = new EmployeeResponseDTO();

		dto.setEmpId(employee.getEmpId());
		dto.setEmpName(employee.getEmpName());
		dto.setEmail(employee.getEmail());
		dto.setSalary(employee.getSalary());

		dto.setDepartmentName(employee.getDepartment().getDeptName());

		dto.setLocation(employee.getDepartment().getLocation());

		return dto;
	}
}