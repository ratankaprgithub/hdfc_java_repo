package com.hdfc.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.hdfc.dto.DeptRequestDTO;
import com.hdfc.dto.DeptResponseDTO;
import com.hdfc.dto.EmployeeInfoRequestDTO;
import com.hdfc.dto.EmployeeInfoResponseDTO;
import com.hdfc.entity.Department;
import com.hdfc.entity.Employee;
import com.hdfc.repository.DepartmentRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DepartmentServiceImpl implements DepartmentService {

	private final DepartmentRepository deptRepo;

	@Override
	public DeptResponseDTO addNewDepartment(DeptRequestDTO dto) {

		Department dept = new Department();
		dept.setDeptName(dto.getDeptName());
		dept.setLocation(dto.getLocation());

		List<Employee> employees = dto.getEmployees().stream().map(empReqDto -> {

			Employee emp = new Employee();

			emp.setEmpName(empReqDto.getEmpName());

			emp.setEmail(empReqDto.getEmail());

			emp.setSalary(empReqDto.getSalary());

			// IMPORTANT
			emp.setDepartment(dept);

			return emp;

		}).collect(Collectors.toList());

		dept.setEmployees(employees);

		Department savedDept = deptRepo.save(dept);

		DeptResponseDTO responseDto = new DeptResponseDTO();
		responseDto.setDeptId(savedDept.getDeptId());
		responseDto.setDeptName(savedDept.getDeptName());
		responseDto.setLocation(savedDept.getLocation());

		List<EmployeeInfoResponseDTO> employeesInfo = savedDept.getEmployees().stream().map(emp -> {

			EmployeeInfoResponseDTO ef = new EmployeeInfoResponseDTO();
			ef.setEmpId(emp.getEmpId());
			ef.setEmpName(emp.getEmpName());
			ef.setEmail(emp.getEmail());
			ef.setSalary(emp.getSalary());

			return ef;

		}).collect(Collectors.toList());

		responseDto.setEmployees(employeesInfo);

		return responseDto;

	}

	@Override
	public List<DeptResponseDTO> getAllDepartment() {

		return deptRepo.findAll().stream().map(dept -> {

			DeptResponseDTO responseDto = new DeptResponseDTO();
			responseDto.setDeptId(dept.getDeptId());
			responseDto.setDeptName(dept.getDeptName());
			responseDto.setLocation(dept.getLocation());

			return responseDto;

		}).collect(Collectors.toList());
	}

	@Override
	public List<EmployeeInfoResponseDTO> getEmployeesByDepartmentId(Integer deptId) {

		Department dept = deptRepo.findById(deptId)
				.orElseThrow(() -> new RuntimeException("Department does not exist.." + deptId));

		List<Employee> employees = dept.getEmployees();

		
		return employees.stream().map(emp -> {

			EmployeeInfoResponseDTO dto = new EmployeeInfoResponseDTO();
			dto.setEmpId(emp.getEmpId());
			dto.setEmpName(emp.getEmpName());
			dto.setEmail(emp.getEmail());
			dto.setSalary(emp.getSalary());

			return dto;

		}).collect(Collectors.toList());

	}

}
