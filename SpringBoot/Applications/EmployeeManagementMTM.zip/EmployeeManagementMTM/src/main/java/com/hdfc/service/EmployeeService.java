package com.hdfc.service;

import java.util.List;

import com.hdfc.dto.EmployeeRequestDTO;
import com.hdfc.dto.EmployeeResponseDTO;

public interface EmployeeService {

	EmployeeResponseDTO saveEmployee(EmployeeRequestDTO dto);

	List<EmployeeResponseDTO> getAllEmployees();

	EmployeeResponseDTO getEmployeeById(Integer empId);

	EmployeeResponseDTO updateEmployee(Integer empId, EmployeeRequestDTO dto);

	EmployeeResponseDTO deleteEmployee(Integer empId);

}
