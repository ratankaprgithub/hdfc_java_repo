package com.hdfc.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hdfc.dto.DeptRequestDTO;
import com.hdfc.dto.DeptResponseDTO;
import com.hdfc.dto.EmployeeInfoResponseDTO;
import com.hdfc.service.DepartmentService;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/departments")
public class DepartmentController {

	private final DepartmentService deptService;

	@PostMapping
	public ResponseEntity<DeptResponseDTO> registerDepartment(@RequestBody DeptRequestDTO reqDto) {

		DeptResponseDTO responseDto = deptService.addNewDepartment(reqDto);

		return ResponseEntity.status(HttpStatus.CREATED).body(responseDto);

	}

	@GetMapping
	public List<DeptResponseDTO> getAllDepartments() {

		return deptService.getAllDepartment();
	}

	@GetMapping("/{deptId}/employees")
	public List<EmployeeInfoResponseDTO> getEmployeesByDepartment(@PathVariable Integer deptId) {

		return deptService.getEmployeesByDepartmentId(deptId);
	}

}
