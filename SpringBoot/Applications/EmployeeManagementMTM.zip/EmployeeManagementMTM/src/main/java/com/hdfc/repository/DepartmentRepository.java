package com.hdfc.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hdfc.entity.Department;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Integer>{

	public Optional<Department> findByDeptName(String deptName);
	
	
	
}
