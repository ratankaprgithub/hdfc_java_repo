package com.hdfc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementMtmApplicationTests {

	@Test
	void contextLoads() {
	}

}
